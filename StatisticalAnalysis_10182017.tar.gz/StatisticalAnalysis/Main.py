import pandas as pd;
import numpy as np;
from sklearn import preprocessing;
from sklearn.datasets import load_iris;
import scipy.stats as sp
from sklearn import decomposition, svm
from sklearn.model_selection import train_test_split,GridSearchCV
import Classifier
import sklearn.ensemble as ske
from sklearn.model_selection import cross_val_score
from sklearn.metrics import make_scorer, accuracy_score
from sklearn.linear_model import LogisticRegression

def dataPreprocessing(df):
    df=df.apply(preprocessing.LabelEncoder().fit_transform)
    #df=df.apply(preprocessing.StandardScaler().fit_transform)
    #df=df.apply(preprocessing.MinMaxScaler().fit_transform)
    return df

def featureSelection(df, k):
    # feature selection based on chi square
    listPVal = []
    for i in range(len(df.columns) - 1):
        freqtab = pd.crosstab(df.iloc[:, i], df.iloc[:, -1])
        chi2, pval, dof, expected = sp.chi2_contingency(freqtab)
        listPVal.append(pval)
    for i in range(len(df.columns) - 1):
        if (listPVal[i] > 0.005):
            df.drop(df.columns[i], axis=1, inplace=True)
    data = df.iloc[:,:len(df.columns)-1]
    Y=df.iloc[:,len(df.columns)-1]
    pca = decomposition.PCA(n_components=k)
    pca.fit(data)
    Xdata = pd.DataFrame(pca.transform(data))
    Xdata[k]=Y
    return Xdata



dataSet = input("What's your choice of dataset?\n"
                "1: bank;"
                "2: titanic;"
                "3: iris;"
                )

if dataSet=='1':
    df = pd.read_csv('./bank/bank.csv', delimiter=';')
elif dataSet=='2':
    df = pd.read_csv('titanic_data.csv')
elif dataSet=='3':
    df=data = load_iris()
else:
    print("dataset could not be found")

df=dataPreprocessing(df)

print (df.head())

k= int(input("choose the number of features you want to keep(integer >1)"))

df=featureSelection(df,k)
print(df.head())

Y = df[k].values.astype(int)
X=df.drop(k, 1).values

data_train, data_test, target_train, target_test = train_test_split(X, Y,test_size=0.2, random_state=43)

# random forrest
cv_num_estimators=0
while True:
    num_estimators=int(input("Let's start with random forrest with cross validation.\n"
                             "Choose number of estimators you want to use for random forrest:"))
    clf_rf = ske.RandomForestClassifier(n_estimators=num_estimators)
    scoresRF = cross_val_score(clf_rf, data_train, target_train, cv=5)
    print(scoresRF)
    crossValResult= int(input("do you think this cross validation result is good?\n"
             "input 1 if yes; input 2 if no"))
    if (crossValResult==1):
        cv_num_estimators=num_estimators
        break

clf_rf = ske.RandomForestClassifier(n_estimators=cv_num_estimators)
clf_rf.fit(data_train,target_train)
predictrf=clf_rf.predict(data_test)
accuracyrf = accuracy_score(target_test, predictrf)
#print(predictrf)
print(accuracyrf)


#Logistic Regression
while True:
    num_estimators=input("Let's try logistic regression with cross validation.\n")
    clf_lr = LogisticRegression()
    scoresRF = cross_val_score(clf_lr, data_train, target_train, cv=5)
    print(scoresRF)
    crossValResult= int(input("do you think this cross validation result is good?\n"
             "input 1 if yes; input 2 if no"))
    if (crossValResult==1):
        cv_num_estimators=num_estimators
        break
clf_lr = LogisticRegression()
clf_lr.fit(data_train,target_train)
predictlr=clf_lr.predict(data_test)
accuracylr = accuracy_score(target_test, predictlr)
#print(predictlr)
print(accuracylr)

for i in range(len(target_test)):
    if ((predictlr[i]!=target_test[i]) | (predictrf[i]!=target_test[i])):
        print("index ", i, "   result should be: " ,target_test[i] , "   RF predict: ",
              predictrf[i] , "   LR predict ",predictlr[i] )

'''

#svm
svmParameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
svr = svm.SVC()
clf = GridSearchCV(svr, svmParameters)
clf.fit(data_train,target_train) '''