import sklearn.ensemble as ske
from sklearn.model_selection import cross_val_predict
import numpy as np
from sklearn.svm import SVC


def clfMethod(trainX, trainY):
    clf_rf = ske.RandomForestClassifier(n_estimators=50)
    probaRF = cross_val_predict(clf_rf, trainX, trainY, cv=10, method='predict_proba')
    #print(probaRF)
    #probaRF.shape()
    probaRF1 = probaRF[:, 1]
    print(probaRF1)
    return probaRF1


def toPredict(x):
    if x >= 0.5:
        return 1
    else:
        return 0

def finalPrediction(prob):
    prediction=map(toPredict, prob)
    finalPrediction=np.fromiter(prediction, dtype=np.int)
    return finalPrediction

def svmMethod(trainX, trainY):
    clf = SVC(kernel='linear', C=1)
    probaRF = cross_val_predict(clf, trainX, trainY, cv=10, method='predict_proba')
    probaRF1 = probaRF[:, 1]
    return probaRF1